import Aritagoras
import Statistika